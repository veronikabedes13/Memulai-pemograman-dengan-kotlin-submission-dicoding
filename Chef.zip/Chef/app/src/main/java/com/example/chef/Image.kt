package com.example.chef

import android.os.Parcelable
import android.os.Parcel
import kotlinx.parcelize.Parcelize

@Parcelize
data class Image(
    val imageSrc : Int,
    val imageTitle: String,
    val imageDesc : String
) : Parcelable

annotation class Parcelize
