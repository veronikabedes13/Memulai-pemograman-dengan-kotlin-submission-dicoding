package com.example.chef

import android.content.Context
import android.os.Parcel
import android.os.Parcelable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.chef.R.id.textView
import com.example.chef.R.id.textView2

class AboutAdapter(
    private val context: Context,
    private val data: List<Pair<String, String>>
) : RecyclerView.Adapter<AboutAdapter.AboutViewHolder>(), Parcelable {

    class AboutViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val keyTextView: TextView = itemView.findViewById(textView)
        private val valueTextView: TextView = itemView.findViewById(textView2)

        fun bind(pair: Pair<String, String>) {
            keyTextView.text = pair.first
            valueTextView.text = pair.second
        }
    }

    constructor(parcel: Parcel) : this(
        TODO("context"),
        TODO("data")
    ) {
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AboutViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.activity_about, parent, false)
        return AboutViewHolder(view)
    }

    override fun onBindViewHolder(holder: AboutViewHolder, position: Int) {
        holder.bind(data[position])
    }

    override fun getItemCount(): Int {
        return data.size
    }

    override fun writeToParcel(parcel: Parcel, flags: Int) {

    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<AboutAdapter> {
        override fun createFromParcel(parcel: Parcel): AboutAdapter {
            return AboutAdapter(parcel)
        }

        override fun newArray(size: Int): Array<AboutAdapter?> {
            return arrayOfNulls(size)
        }
    }
}
