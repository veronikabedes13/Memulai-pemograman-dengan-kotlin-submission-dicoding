package com.example.chef

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.appcompat.app.AppCompatActivity

class Splash : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Set layout for splash screen if needed
        setContentView(R.layout.splash_screen)

        // Delay for splash screen in milliseconds (e.g., 2000 milliseconds = 2 seconds)
        val splashScreenDuration = 2000L

        // Create a new thread that will sleep for the splash screen duration
        val splashScreenThread = object : Thread() {
            override fun run() {
                try {
                    sleep(splashScreenDuration)
                } catch (e: InterruptedException) {
                    e.printStackTrace()
                } finally {
                    // Start the MainActivity after the splash screen duration
                    startActivity(Intent(applicationContext, MainActivity::class.java))
                    finish()
                }
            }
        }

        // Start the splash screen thread
        splashScreenThread.start()
    }
}

