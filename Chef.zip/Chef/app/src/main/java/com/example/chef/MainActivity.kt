package com.example.chef

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import androidx.activity.ComponentActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.chef.R.id.user_icon

class MainActivity : ComponentActivity() {

    companion object{
        val INTENT_PARCELABLE = "OBJECT_INTENT"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val imageList = listOf<Image>(
            Image(
                R.drawable.seblak,
                "Seblak",
                " Seblak adalah salah satu makanan yang cukup populer di Indonesia, terutama sebagai makanan ringan atau sebagai hidangan utama. Berikut adalah resep dan bahan-bahan yang dibutuhkan untuk membuat seblak:\n" +
                        "\n" +
                        "Bahan-Bahan:\n" +
                        "200 gram kerupuk (biasanya menggunakan kerupuk aci atau kerupuk bawang)\n" +
                        "100 gram mie instan (pilihlah mie instan tanpa bumbu)\n" +
                        "100 gram kacang tanah, digoreng\n" +
                        "100 gram tahu, potong dadu\n" +
                        "100 gram bakso ikan atau bakso sapi, potong dadu\n" +
                        "3 siung bawang putih, cincang halus\n" +
                        "2 batang daun bawang, iris tipis\n" +
                        "2 sdm saus sambal\n" +
                        "2 sdm saus tomat\n" +
                        "2 sdm kecap manis\n" +
                        "1 sdm minyak sayur\n" +
                        "1 sdm bawang merah goreng (optional)\n" +
                        "Air secukupnya\n" +
                        "Garam, gula, dan merica secukupnya\n" +
                        "Bahan pelengkap (kerupuk, bawang merah goreng, irisan daun bawang, dll.)\n" +
                        "Langkah-langkah:\n" +
                        "Siapkan Bahan Utama:\n" +
                        "\n" +
                        "Rebus mie instan hingga matang. Tiriskan dan sisihkan.\n" +
                        "Rebus kerupuk aci hingga mengembang. Tiriskan dan sisihkan.\n" +
                        "Goreng tahu hingga kecokelatan. Tiriskan dan sisihkan.\n" +
                        "Goreng bakso ikan atau bakso sapi hingga matang. Tiriskan dan sisihkan.\n" +
                        "Goreng kacang tanah hingga kecokelatan. Tiriskan dan sisihkan.\n" +
                        "Tumis Bumbu:\n" +
                        "\n" +
                        "Panaskan minyak sayur dalam wajan. Tumis bawang putih hingga harum.\n" +
                        "Masukkan bakso, tahu, dan mie instan. Aduk rata.\n" +
                        "Tambahkan Saus:\n" +
                        "\n" +
                        "Tuangkan saus sambal, saus tomat, dan kecap manis ke dalam tumisan. Aduk rata.\n" +
                        "Tambahkan Air:\n" +
                        "\n" +
                        "Tambahkan air secukupnya ke dalam tumisan hingga tercium aroma harum dan bumbu meresap.\n" +
                        "Bumbui:\n" +
                        "\n" +
                        "Tambahkan garam, gula, dan merica secukupnya sesuai dengan selera. Aduk rata.\n" +
                        "Penyajian:\n" +
                        "\n" +
                        "Masukkan kerupuk aci ke dalam tumisan dan aduk rata hingga semua bahan tercampur merata dan bumbu meresap.\n" +
                        "Sajikan segera dengan taburan bawang merah goreng dan irisan daun bawang sebagai hiasan.\n" +
                        "Selamat mencoba! Semoga berhasil dan enak!"
            ),
            Image(
                R.drawable.bakso,
                "Bakso",
                "\n" +
                        "Berikut adalah resep dan cara membuat Bakso:\n" +
                        "\n" +
                        "Bahan-bahan:\n" +
                        "Bakso Ayam:\n" +
                        "300 gram daging ayam giling\n" +
                        "100 gram tepung sagu\n" +
                        "1 butir telur\n" +
                        "2 sendok makan tepung tapioka\n" +
                        "2 siung bawang putih, haluskan\n" +
                        "Garam dan merica secukupnya\n" +
                        "Es batu secukupnya\n" +
                        "Kuah Bakso:\n" +
                        "1 liter kaldu ayam\n" +
                        "2 siung bawang putih, geprek\n" +
                        "2 daun bawang, potong-potong\n" +
                        "Garam dan merica secukupnya\n" +
                        "Kecap manis dan saus sambal secukupnya (opsional)\n" +
                        "Cara Pembuatan:\n" +
                        "Bakso Ayam:\n" +
                        "Campur daging ayam giling, tepung sagu, tepung tapioka, telur, bawang putih, garam, dan merica dalam satu wadah.\n" +
                        "Uleni adonan hingga merata. Tambahkan es batu sedikit-sedikit sambil terus diulen hingga adonan kenyal.\n" +
                        "Ambil sejumput adonan bakso, bulatkan dengan tangan yang sudah dibasahi air.\n" +
                        "Rebus air dalam panci. Setelah itu, masukkan bakso satu per satu ke dalam air mendidih hingga bakso mengapung. Angkat dan tiriskan.\n" +
                        "Kuah Bakso:\n" +
                        "Rebus kaldu ayam dalam panci. Tambahkan bawang putih, daun bawang, garam, dan merica sesuai selera.\n" +
                        "Biarkan kuah mendidih dan bumbu meresap.\n" +
                        "Siapkan mangkuk, letakkan bakso yang sudah direbus di dalamnya.\n" +
                        "Tuangkan kuah panas ke dalam mangkuk hingga menutupi bakso.\n" +
                        "Tambahkan kecap manis dan saus sambal jika suka.\n" +
                        "Penyajian:\n" +
                        "Bakso siap disajikan panas-panas. Anda juga bisa menambahkan mie rebus, bihun, tahu, atau sayuran sesuai selera.\n" +
                        "Hidangkan bakso dengan sambal, kecap manis, atau saus tomat jika diinginkan.\n" +
                        "Selamat mencoba membuat bakso! Semoga berhasil dan lezat.."
            ),
            Image(
                R.drawable.soto,
                "Soto Ayam",
                " berikut adalah resep dan cara pembuatan Soto Ayam:\n" +
                        "\n" +
                        "Bahan-bahan:\n" +
                        "1 ekor ayam, potong menjadi bagian-bagian kecil\n" +
                        "2 liter air\n" +
                        "4 batang serai, memarkan\n" +
                        "5 lembar daun jeruk\n" +
                        "4 lembar daun salam\n" +
                        "2 batang sereh, memarkan\n" +
                        "5 cm jahe, memarkan\n" +
                        "5 siung bawang putih, memarkan\n" +
                        "4 cm lengkuas, memarkan\n" +
                        "2 sendok makan minyak goreng\n" +
                        "Garam secukupnya\n" +
                        "Gula secukupnya\n" +
                        "Merica secukupnya\n" +
                        "Bawang goreng secukupnya\n" +
                        "200 gram tauge, seduh dengan air panas, tiriskan\n" +
                        "200 gram bihun, seduh dengan air panas, tiriskan\n" +
                        "Daun seledri, iris halus (untuk taburan)\n" +
                        "Bawang merah goreng (untuk taburan)\n" +
                        "Jeruk nipis, potong menjadi irisan (opsional)\n" +
                        "Bumbu Halus:\n" +
                        "6 butir bawang merah\n" +
                        "4 siung bawang putih\n" +
                        "3 cm kunyit\n" +
                        "3 cm jahe\n" +
                        "2 batang sereh, bagian putihnya saja\n" +
                        "1 sendok teh ketumbar bubuk\n" +
                        "1/2 sendok teh jinten bubuk\n" +
                        "Cara Pembuatan:\n" +
                        "Rebus Ayam:\n" +
                        "\n" +
                        "Didihkan air dalam panci besar, masukkan potongan ayam, serai, daun jeruk, daun salam, jahe, bawang putih, dan lengkuas.\n" +
                        "Rebus ayam hingga empuk dan kaldu terasa gurih. Angkat ayam, sisihkan kaldu.\n" +
                        "Tumis Bumbu Halus:\n" +
                        "\n" +
                        "Tumis bumbu halus dengan minyak goreng hingga harum dan matang.\n" +
                        "Tambahkan Kaldu:\n" +
                        "\n" +
                        "Tuang kaldu ayam ke dalam tumisan bumbu halus. Rebus hingga mendidih.\n" +
                        "Beri Bumbu:\n" +
                        "\n" +
                        "Tambahkan garam, gula, dan merica secukupnya sesuai selera. Aduk rata.\n" +
                        "Penyajian:\n" +
                        "\n" +
                        "Siapkan mangkuk saji, isi dengan bihun dan tauge yang sudah diseduh.\n" +
                        "Letakkan potongan ayam rebus di atas bihun dan tauge.\n" +
                        "Tuang kuah soto ayam ke dalam mangkuk.\n" +
                        "Taburi dengan daun seledri, bawang goreng, dan irisan jeruk nipis (opsional).\n" +
                        "Soto ayam siap disajikan hangat.\n" +
                        "Selamat mencoba membuat soto ayam! "
            ),
            Image(
                R.drawable.mie,
                "Mie Cakalang",
                "Berikut adalah resep dan cara pembuatan Soto Ayam:\n" +
                        "\n" +
                        "Bahan-bahan:\n" +
                        "500 gram daging ayam (bagian dada atau paha), potong-potong\n" +
                        "200 gram mie soun (sohun), rendam air panas hingga lunak, tiriskan\n" +
                        "2 liter air\n" +
                        "2 batang serai, memarkan\n" +
                        "3 lembar daun jeruk\n" +
                        "3 lembar daun salam\n" +
                        "2 cm jahe, memarkan\n" +
                        "3 siung bawang putih, geprek\n" +
                        "2 sendok teh garam (atau sesuai selera)\n" +
                        "1 sendok teh merica bubuk\n" +
                        "1 sendok makan minyak goreng\n" +
                        "2 sendok makan kecap manis (opsional)\n" +
                        "2 sendok makan air jeruk nipis (opsional)\n" +
                        "1 batang daun bawang, iris halus\n" +
                        "2 sendok makan bawang merah goreng (untuk taburan)\n" +
                        "Bumbu Halus:\n" +
                        "4 siung bawang putih\n" +
                        "6 butir bawang merah\n" +
                        "2 cm kunyit, bakar\n" +
                        "2 cm jahe\n" +
                        "Pelengkap:\n" +
                        "Tauge, bersihkan\n" +
                        "Daun seledri, iris halus\n" +
                        "Jeruk nipis, iris\n" +
                        "Sambal (opsional)\n" +
                        "Cara Pembuatan:\n" +
                        "Rebus Ayam:\n" +
                        "\n" +
                        "Didihkan air dalam panci. Masukkan potongan daging ayam, serai, daun jeruk, daun salam, jahe, dan bawang putih geprek. Masak dengan api sedang hingga daging ayam empuk dan kuah bercita rasa.\n" +
                        "Tumis Bumbu Halus:\n" +
                        "\n" +
                        "Panaskan minyak goreng dalam wajan. Tumis bumbu halus hingga harum dan matang.\n" +
                        "Tambahkan Bumbu Tumis ke Kuah Ayam:\n" +
                        "\n" +
                        "Masukkan bumbu tumis ke dalam kuah ayam yang sedang direbus. Aduk rata.\n" +
                        "Tambahkan Bumbu Lain:\n" +
                        "\n" +
                        "Tambahkan garam dan merica bubuk. Koreksi rasa sesuai selera. Jika suka, tambahkan kecap manis dan air jeruk nipis. Aduk rata.\n" +
                        "Penyajian:\n" +
                        "\n" +
                        "Siapkan mangkuk saji. Letakkan soun (sohun) yang sudah direndam di dasar mangkuk.\n" +
                        "Ambil potongan daging ayam dari kuah, letakkan di atas soun.\n" +
                        "Tuang kuah soto ke dalam mangkuk, hingga menutupi daging ayam dan soun.\n" +
                        "Hiasi dengan tauge, daun seledri, irisan jeruk nipis, dan bawang merah goreng.\n" +
                        "Sajikan soto ayam hangat dengan sambal sebagai pelengkapnya.\n" +
                        "Selamat mencoba membuat soto ayam"
            ),
            Image(
                R.drawable.dimsum,
                "Dimsum Ayam Udang",
                "Berikut adalah resep dan cara pembuatan Dim Sum Ayam Udang (Chicken Shrimp Dumplings):\n" +
                        "\n" +
                        "Bahan-bahan:\n" +
                        "Isian:\n" +
                        "200 gram daging ayam cincang\n" +
                        "100 gram udang kupas, cincang\n" +
                        "2 siung bawang putih, cincang halus\n" +
                        "1 sendok makan kecap asin\n" +
                        "1 sendok makan kecap manis\n" +
                        "1 sendok makan minyak wijen\n" +
                        "1 sendok teh gula pasir\n" +
                        "1 sendok teh merica bubuk\n" +
                        "1/2 sendok teh garam\n" +
                        "1/2 sendok teh minyak wijen\n" +
                        "Kulit Dumpling:\n" +
                        "200 gram tepung terigu protein tinggi\n" +
                        "100 gram tepung tapioka\n" +
                        "200 ml air dingin\n" +
                        "1/2 sendok teh garam\n" +
                        "Bahan Pelengkap:\n" +
                        "Cabe rawit merah, iris halus (opsional)\n" +
                        "Kecap asin\n" +
                        "Saus sambal (opsional)\n" +
                        "Cara Pembuatan:\n" +
                        "Persiapan Bahan:\n" +
                        "\n" +
                        "Campur semua bahan isian dalam mangkuk besar. Aduk hingga tercampur rata. Sisihkan.\n" +
                        "Campur tepung terigu, tepung tapioka, dan garam dalam mangkuk besar untuk kulit dumpling. Tuangkan air dingin sedikit demi sedikit sambil terus diaduk hingga menjadi adonan yang lembut dan elastis. Istirahatkan adonan selama 30 menit.\n" +
                        "Pembentukan Dumpling:\n" +
                        "\n" +
                        "Ambil selembar kulit dumpling. Letakkan satu sendok makan adonan isian di tengahnya. Lipat kulit dumpling menjadi bentuk setengah lingkaran, tekan dan rapihkan pinggirannya dengan jari-jari.\n" +
                        "Ulangi langkah tersebut sampai adonan habis.\n" +
                        "Perebusan:\n" +
                        "\n" +
                        "Panaskan air dalam panci hingga mendidih. Letakkan dumpling dalam panci dengan jarak satu sama lain. Rebus dumpling hingga mengapung dan kulitnya menjadi bening, sekitar 5-7 menit.\n" +
                        "Penyajian:\n" +
                        "\n" +
                        "Angkat dumpling dengan sendok berlubang, tiriskan.\n" +
                        "Sajikan dim sum ayam udang panas dengan cabe rawit iris, kecap asin, dan saus sambal sebagai pelengkapnya.\n" +
                        "Selamat mencoba membuat dim sum ayam udang"
            ),
            Image(
                R.drawable.telur,
                "Telur Balado",
                "Berikut adalah resep dan cara pembuatan Telur Balado:\n" +
                        "\n" +
                        "Bahan-bahan:\n" +
                        "6 butir telur, rebus dan kupas\n" +
                        "5 buah cabai merah besar\n" +
                        "3 buah cabai rawit merah (sesuai selera pedas)\n" +
                        "4 siung bawang merah\n" +
                        "3 siung bawang putih\n" +
                        "2 buah tomat\n" +
                        "1 sendok makan gula merah, sisir halus\n" +
                        "1 sendok teh garam (atau sesuai selera)\n" +
                        "1/2 sendok teh merica bubuk\n" +
                        "Minyak goreng secukupnya\n" +
                        "Air secukupnya\n" +
                        "Cara Pembuatan:\n" +
                        "Membuat Bumbu Balado:\n" +
                        "\n" +
                        "Haluskan cabai merah besar, cabai rawit, bawang merah, dan bawang putih menggunakan blender atau ulekan.\n" +
                        "Menggoreng Telur:\n" +
                        "\n" +
                        "Panaskan minyak dalam wajan. Goreng telur rebus hingga kulitnya agak kering dan kecokelatan. Angkat dan tiriskan.\n" +
                        "Membuat Saus Balado:\n" +
                        "\n" +
                        "Panaskan sedikit minyak dalam wajan. Tumis bumbu halus hingga harum dan matang.\n" +
                        "Masukkan tomat yang sudah diiris-iris, gula merah, garam, dan merica bubuk. Aduk rata dan masak hingga tomat hancur dan bumbu tercampur merata.\n" +
                        "Tambahkan sedikit air jika bumbu terlalu kental. Masak hingga bumbu menyusut dan matang. Koreksi rasa sesuai selera.\n" +
                        "Menyajikan Telur Balado:\n" +
                        "\n" +
                        "Potong telur rebus menjadi dua bagian.\n" +
                        "Letakkan telur rebus dalam piring saji.\n" +
                        "Siramkan saus balado di atas telur.\n" +
                        "Telur balado siap disajikan bersama nasi hangat sebagai lauk utama.\n" +
                        "Selamat mencoba membuat telur balado"
            ),
            Image(
                R.drawable.pecellele,
                "Pecel Lele",
                "Berikut adalah resep dan cara pembuatan Pecel Lele:\n" +
                        "\n" +
                        "Bahan-bahan:\n" +
                        "Lele Goreng:\n" +
                        "4 ekor lele, bersihkan dan belah menjadi dua bagian\n" +
                        "2 sendok makan air jeruk nipis\n" +
                        "1 sendok teh garam\n" +
                        "Minyak goreng secukupnya untuk menggoreng\n" +
                        "Bumbu Pecel:\n" +
                        "100 gram kacang tanah, sangrai dan haluskan\n" +
                        "2 siung bawang putih\n" +
                        "2 buah cabai rawit (sesuai selera)\n" +
                        "3 buah cabai merah besar\n" +
                        "2 sendok makan petis udang\n" +
                        "1 sendok makan gula merah, sisir halus\n" +
                        "1 sendok teh terasi, bakar\n" +
                        "1 sendok teh garam\n" +
                        "Air secukupnya\n" +
                        "Pelengkap:\n" +
                        "Lalapan (mentimun, kubis, kacang panjang, daun kemangi)\n" +
                        "Kerupuk (kerupuk udang, kerupuk bawang, dll.)\n" +
                        "Cara Pembuatan:\n" +
                        "Lele Goreng:\n" +
                        "\n" +
                        "Lumuri lele dengan air jeruk nipis dan garam. Diamkan selama 15-30 menit.\n" +
                        "Panaskan minyak dalam wajan. Goreng lele hingga kecokelatan dan matang. Angkat dan tiriskan.\n" +
                        "Bumbu Pecel:\n" +
                        "\n" +
                        "Haluskan bawang putih, cabai rawit, dan cabai merah besar menggunakan blender atau ulekan.\n" +
                        "Campurkan kacang tanah yang sudah dihaluskan, bumbu halus, petis udang, gula merah, terasi bakar, dan garam dalam mangkuk besar.\n" +
                        "Tambahkan air sedikit demi sedikit sambil terus diaduk hingga menjadi konsistensi yang kental dan lembut. Koreksi rasa sesuai selera.\n" +
                        "Penyajian:\n" +
                        "\n" +
                        "Tata lalapan di piring saji.\n" +
                        "Letakkan lele goreng di atas lalapan.\n" +
                        "Siramkan bumbu pecel di atas lele goreng.\n" +
                        "Sajikan pecel lele bersama dengan kerupuk sebagai pelengkapnya.\n" +
                        "Selamat mencoba membuat pecel lele!"
            ),
            Image(
                R.drawable.gado,
                "Gado gado",
                "Berikut adalah resep dan cara pembuatan Gado-Gado:\n" +
                        "\n" +
                        "Bahan-bahan:\n" +
                        "Bahan Utama:\n" +
                        "200 gram tahu, potong-potong dan goreng\n" +
                        "200 gram tempe, potong-potong dan goreng\n" +
                        "200 gram kacang panjang, potong-potong dan rebus\n" +
                        "200 gram tauge, rebus sebentar\n" +
                        "2 buah kentang, kupas, potong dadu, dan rebus\n" +
                        "2 lembar kol, iris halus dan rebus sebentar\n" +
                        "Daun selada (secukupnya, sebagai alas penyajian)\n" +
                        "Bahan Pelengkap:\n" +
                        "Telur rebus, belah menjadi dua bagian (opsional)\n" +
                        "Kerupuk (kerupuk udang, kerupuk bawang, dll.)\n" +
                        "Bawang merah goreng (untuk taburan, opsional)\n" +
                        "Bahan Sambal Kacang:\n" +
                        "150 gram kacang tanah, sangrai\n" +
                        "3 buah cabai merah keriting\n" +
                        "3 siung bawang putih\n" +
                        "2 sendok makan gula merah, sisir halus\n" +
                        "2 sendok makan petis udang\n" +
                        "1 sendok makan tamarind paste (air asam jawa)\n" +
                        "Garam secukupnya\n" +
                        "Air secukupnya\n" +
                        "Cara Pembuatan:\n" +
                        "Membuat Sambal Kacang:\n" +
                        "\n" +
                        "Haluskan kacang tanah, cabai merah keriting, dan bawang putih menggunakan blender atau ulekan.\n" +
                        "Tambahkan gula merah, petis udang, tamarind paste, garam, dan air. Aduk hingga merata dan menjadi konsistensi saus kacang. Koreksi rasa sesuai selera.\n" +
                        "Menyusun Gado-Gado:\n" +
                        "\n" +
                        "Susun semua bahan utama (tahu, tempe, kacang panjang, tauge, kentang, kol, dan daun selada) di atas piring saji.\n" +
                        "Tata telur rebus dan kerupuk di sekitar bahan utama.\n" +
                        "Taburi bawang merah goreng di atasnya.\n" +
                        "Penyajian:\n" +
                        "\n" +
                        "Sajikan gado-gado bersama sambal kacang. Saat menyajikan, tuang sambal kacang di atas gado-gado sesuai selera.\n" +
                        "Selamat mencoba membuat gado-gado!"
            ),
            Image(
                R.drawable.sate,
                "Sate Ayam",
                "Berikut adalah resep dan cara pembuatan Sate Ayam:\n" +
                        "\n" +
                        "Bahan-bahan:\n" +
                        "Bahan Utama:\n" +
                        "500 gram daging ayam (dada atau paha), potong-potong kotak\n" +
                        "Bambu sate secukupnya (sebelumnya direndam dalam air agar tidak gosong saat dipanggang)\n" +
                        "Bumbu Marinasi:\n" +
                        "3 siung bawang putih, haluskan\n" +
                        "2 sendok makan kecap manis\n" +
                        "1 sendok makan kecap asin\n" +
                        "1 sendok makan minyak goreng\n" +
                        "1 sendok teh gula merah, sisir halus (opsional)\n" +
                        "1/2 sendok teh merica bubuk\n" +
                        "Garam secukupnya (jika diperlukan)\n" +
                        "Saus Kacang:\n" +
                        "150 gram kacang tanah, sangrai dan haluskan\n" +
                        "2 siung bawang putih, haluskan\n" +
                        "2 sendok makan kecap manis\n" +
                        "1 sendok makan kecap asin\n" +
                        "1/2 sendok teh gula merah, sisir halus\n" +
                        "1/2 sendok teh garam\n" +
                        "Air secukupnya\n" +
                        "1 buah cabai merah besar, haluskan (jika suka pedas)\n" +
                        "Pelengkap:\n" +
                        "Bawang merah iris\n" +
                        "Bawang goreng\n" +
                        "Timun iris\n" +
                        "Tomat iris\n" +
                        "Lontong atau nasi putih\n" +
                        "Cara Pembuatan:\n" +
                        "Marinasi Daging Ayam:\n" +
                        "\n" +
                        "Campurkan semua bahan marinasi (bawang putih, kecap manis, kecap asin, minyak goreng, gula merah, merica bubuk, dan garam) dalam mangkuk.\n" +
                        "Masukkan potongan daging ayam ke dalam bumbu marinasi, aduk rata. Diamkan dalam kulkas selama minimal 1 jam atau semalam untuk hasil yang lebih meresap.\n" +
                        "Tusuk Daging Ayam dengan Bambu Sate:\n" +
                        "\n" +
                        "Tusuk potongan daging ayam ke tusukan bambu sate yang sudah direndam air.\n" +
                        "Panggang Sate Ayam:\n" +
                        "\n" +
                        "Panggang sate ayam di atas panggangan dengan api sedang hingga matang dan kecokelatan, sambil sesekali diolesi sisa bumbu marinasi.\n" +
                        "Saus Kacang:\n" +
                        "\n" +
                        "Campur semua bahan saus kacang (kacang tanah halus, bawang putih, kecap manis, kecap asin, gula merah, garam, air, dan cabai merah halus) dalam mangkuk. Aduk hingga merata dan kental.\n" +
                        "Penyajian:\n" +
                        "\n" +
                        "Sajikan sate ayam panas-panas dengan saus kacang sebagai pelengkap. Hidangkan bersama bawang merah iris, bawang goreng, timun, tomat, dan lontong atau nasi putih.\n" +
                        "Selamat mencoba membuat sate ayam!"
            ),
            Image(
                R.drawable.spageti,
                "Spageti",
                "Berikut adalah resep dan cara pembuatannya:\n" +
                        "\n" +
                        "Bahan-bahan:\n" +
                        "200 gram spaghetti\n" +
                        "2 sendok makan minyak zaitun\n" +
                        "3 siung bawang putih, cincang halus\n" +
                        "1 buah bawang bombay, cincang halus\n" +
                        "1 kaleng (400 gram) saus tomat\n" +
                        "1 sendok teh gula\n" +
                        "1/2 sendok teh oregano kering\n" +
                        "1/2 sendok teh basil kering\n" +
                        "1/2 sendok teh merica bubuk\n" +
                        "Garam secukupnya\n" +
                        "Keju parmesan parut (opsional, untuk taburan)\n" +
                        "Cara Pembuatan:\n" +
                        "Memasak Spaghetti:\n" +
                        "\n" +
                        "Rebus spaghetti dalam air mendidih yang diberi sedikit garam hingga al dente (sesuai petunjuk kemasan). Tiriskan dan sisihkan.\n" +
                        "Membuat Saus Tomat:\n" +
                        "\n" +
                        "Panaskan minyak zaitun dalam wajan besar. Tumis bawang putih dan bawang bombay hingga harum dan berwarna keemasan.\n" +
                        "Tambahkan saus tomat, gula, oregano, basil, merica bubuk, dan garam. Aduk rata dan biarkan mendidih.\n" +
                        "Kecilkan api dan biarkan saus tomat mendidih perlahan selama sekitar 10-15 menit, atau hingga saus sedikit mengental. Koreksi rasa sesuai selera.\n" +
                        "Menggabungkan Spaghetti dan Saus:\n" +
                        "\n" +
                        "Masukkan spaghetti yang sudah direbus ke dalam wajan berisi saus tomat.\n" +
                        "Aduk rata hingga spaghetti terbalut dengan baik oleh saus.\n" +
                        "Penyajian:\n" +
                        "\n" +
                        "Sajikan spaghetti dengan saus tomat di atas piring saji.\n" +
                        "Taburi dengan keju parmesan parut jika diinginkan.\n" +
                        "Spaghetti dengan saus tomat siap disajikan panas sebagai hidangan utama.\n" +
                        "Selamat mencoba membuat spaghetti "
            )
        )

        val recyclerView = findViewById<RecyclerView>(R.id._imageRecyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.setHasFixedSize(true)
        recyclerView.adapter = ImageAdapter(this, imageList){
            val intent = Intent(this, DetailActivity::class.java)
            intent.putExtra(INTENT_PARCELABLE, it)
            startActivity(intent)
        }

    }

}
