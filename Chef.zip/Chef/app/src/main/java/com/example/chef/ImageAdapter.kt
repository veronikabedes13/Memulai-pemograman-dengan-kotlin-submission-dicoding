package com.example.chef

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ImageAdapter(
    private val context: Context,
    private val images: List<Image>,
    val listener: (Image) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private val HEADER_VIEW = 0
    private val ITEM_VIEW = 1

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return when (viewType) {
            HEADER_VIEW -> HeaderViewHolder(LayoutInflater.from(context).inflate(R.layout.header, parent, false))
            ITEM_VIEW -> ImageViewHolder(LayoutInflater.from(context).inflate(R.layout.item_image, parent, false))
            else -> throw IllegalArgumentException("Invalid view type")
        }
    }

    override fun getItemCount(): Int = images.size + 1 // Add one for the header

    override fun getItemViewType(position: Int): Int {
        return if (position == 0) HEADER_VIEW else ITEM_VIEW
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (holder) {
            is HeaderViewHolder -> {
                // Bind header data here
                // For example:
                holder.userIcon.setImageResource(R.drawable.user)
                holder.menuTitle.text = "Menu Makanan"
                holder.itemView.setOnClickListener {
                    // Handle header click
                    val intent = Intent(context, AboutActivity::class.java)
                    context.startActivity(intent)
                }

            }
            is ImageViewHolder -> {
                // Bind image data here
                val image = images[position - 1] // Adjust position to account for the header
                holder.bindView(image, listener)

                holder.itemView.setOnClickListener {
                    val intent = Intent(context, DetailActivity::class.java)
                    intent.putExtra(MainActivity.INTENT_PARCELABLE, image)
                    context.startActivity(intent)
                }
            }
        }
    }

    // Header ViewHolder
    class HeaderViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val userIcon = view.findViewById<ImageView>(R.id.user_icon)
        val menuTitle = view.findViewById<TextView>(R.id.textView3)
    }

    // Image ViewHolder
    class ImageViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val imageSrc = view.findViewById<ImageView>(R.id._image)
        val title = view.findViewById<TextView>(R.id._title)
        fun bindView(image: Image, listener: (Image) -> Unit) {
            imageSrc.setImageResource(image.imageSrc)
            title.text = image.imageTitle
            itemView.setOnClickListener { listener(image) }
        }
    }
}


