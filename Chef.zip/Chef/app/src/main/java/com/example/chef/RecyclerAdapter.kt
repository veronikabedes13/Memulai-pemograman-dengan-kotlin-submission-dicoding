//package com.example.chef
//
//import android.view.LayoutInflater
//import android.view.View
//import android.view.ViewGroup
//import android.widget.ImageView
//import android.widget.TextView
//import androidx.recyclerview.widget.RecyclerView
//
//class RecyclerAdapter : RecyclerView.Adapter<RecyclerAdapter.ViewHolder>() {
//
//    private var titles = arrayOf("Seblak", "Bakso", "Soto Ayam", "Mie Cakalang", "Dimsum", "Telur Balado", "Pecel Lele","Gado-gado","Sate Ayam","Spagetti")
//
//    private var details= arrayOf(
//        "Hidangan Indonesia asal Bandung, terdiri dari mie, kerupuk, sayuran, dan tambahan seperti telur, bakso, dan daging yang dimasak dengan bumbu pedas khas",
//        "Bola daging sapi yang biasanya disajikan dalam kuah kaldu, sering disertai dengan mie, tahu, telur, dan sayuran.",
//        "Hidangan sup khas Indonesia yang terbuat dari kaldu ayam yang gurih, disajikan dengan potongan daging ayam, mie ",
//        "Hidangan khas dari Manado, Indonesia, yang terdiri dari mie kuning yang disajikan dengan irisan ikan cakalang (tuna sirip biru) yang diasap atau digoreng kering.",
//        "Hidangan khas dari masakan Kanton, China, yang terdiri dari berbagai jenis makanan kecil seperti pangsit, bakpao, dan gulungan isi daging atau seafood yang dikukus, direbus, atau digoreng",
//        "Hidangan Indonesia yang terdiri dari telur rebus yang disajikan dengan saus balado, saus pedas khas Indonesia yang terbuat dari cabai, bawang, tomat, dan bumbu-bumbu lainnya. ",
//        "Hidangan yang terdiri dari ikan lele goreng yang disajikan dengan sambal kacang, lalapan (sayuran mentah), dan nasi.",
//        "Salad yang terdiri dari berbagai macam sayuran seperti kentang, tahu, tempe, dan taoge yang disajikan dengan sambal kacang.",
//        "Potongan daging yang ditusuk dengan bambu dan kemudian dipanggang. Sate sering disajikan dengan bumbu kacang dan nasi.",
//        "Hidangan pasta khas Italia yang terbuat dari adonan tepung gandum dan air, yang biasanya disajikan dengan berbagai jenis saus seperti saus tomat, saus bolognaise (sauce bolognaise), atau saus carbonara")
//
//    private val images = intArrayOf(R.drawable.seblak, R.drawable.bakso, R.drawable.soto, R.drawable.mie,R.drawable.dimsum, R.drawable.telur ,R.drawable.pecellele, R.drawable.gado, R.drawable.sate, R.drawable.spageti)
//
//    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerAdapter.ViewHolder {
//        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_food, parent, false)
//        return ViewHolder(v)
//    }
//
//    override fun onBindViewHolder(holder: RecyclerAdapter.ViewHolder, position: Int) {
//       holder.itemTitle.text = titles[position]
//       holder.itemDetail.text = details[position]
//       holder.itemImage.setImageResource(images[position])
//
//    }
//
//    override fun getItemCount(): Int {
//        return titles.size
//    }
//    inner class ViewHolder(itemView: View): RecyclerView.ViewHolder(itemView) {
//        var itemImage: ImageView
//        var itemTitle: TextView
//        var itemDetail: TextView
//
//        init {
//            itemImage = itemView.findViewById(R.id.item_image)
//            itemTitle = itemView.findViewById(R.id.item_title)
//            itemDetail = itemView.findViewById(R.id.item_detail)
//        }
//    }
//
//}