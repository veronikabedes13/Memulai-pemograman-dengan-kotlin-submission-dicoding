package com.example.chef

import android.os.Bundle
import android.widget.TextView
import androidx.activity.ComponentActivity

class AboutActivity: ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_about)

        findViewById<TextView>(R.id.textView).text
        findViewById<TextView>(R.id.textView2).text

    }
}